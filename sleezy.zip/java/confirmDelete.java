/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pr2;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author figaro
 */
@WebServlet(urlPatterns = {"/confirmDelete"}, name="confirmDelete")
public class confirmDelete extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String redirectTo;
        DB db = new DB();
        System.out.println(Integer.parseInt(request.getParameter("id")));
        System.out.println(db.imageExistsID(Integer.parseInt(request.getParameter("id"))));
        if( request.getParameter("id") == null 
                || !db.imageExistsID(Integer.parseInt(request.getParameter("id")))) redirectTo = "menu.jsp";
        else redirectTo = "confirmDelete.jsp";
        
        request.getRequestDispatcher(redirectTo).forward(request, response); 
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DB db = new DB();
        db.deleteImageID(Integer.valueOf(request.getParameter("id")));

        response.sendRedirect(request.getContextPath() + "/menu");
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
}
